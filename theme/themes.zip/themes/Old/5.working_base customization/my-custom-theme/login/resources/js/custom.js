document.addEventListener("DOMContentLoaded", () => {
    console.log("Custom theme JS loaded");
});
